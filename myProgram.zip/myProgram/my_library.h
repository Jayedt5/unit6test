#ifndef MY_LIBRARY_H
#define MY_LIBRARY_H

#include <Arduino.h>

int addTwoInts(int a, int b);

#endif